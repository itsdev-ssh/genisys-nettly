<?php

namespace App\Console\Commands;

use App\Models\Product;
use App\Models\Server;
use App\Models\User;
use App\Notifications\ServersBeforeSuspendedNotification;
use App\Notifications\ServersSuspendedNotification;
use Carbon\Carbon;
use Illuminate\Console\Command;

class suspendInactive extends Command
{
    const DAYS_UNTIL_SERVER_GETS_SUSPENDED = 14; //default to 14 years. Number in Days. Change to your liking
    const DAYS_UNTIL_SERVER_GETS_DELETED = 1095; //default to 3 years just to be sure. Number in Days. Change to your liking

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'servers:check:inactive';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Check for users who havent been logged in for a while and suspend their free Servers';


    /**
     * A list of users that have to be notified
     * @var array
     */
    protected $usersToNotifySuspended = [];
    protected $usersToNotifyBeforeSuspend = [];

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return string
     */
    public function handle()
    {
        $this->line("<fg=green>RUNNING SCRIPT - Inactive Server Suspend - </>");

            Server::whereNull('suspended')->chunk(10, function ($servers) {
                /** @var Server $server */
                foreach ($servers as $server) {
                    /** @var Product $product */
                    $product = $server->product;
                    /** @var User $user */
                    $user = $server->user;
                    if ($user->role == "admin") {
                        return;
                    }//Disable for admins

                    $today = Carbon::today()->toDateString();

                    #notify user 1 day before
                    if ($product->price == 0 && $user->last_seen->diffInDays($today) >= $this::DAYS_UNTIL_SERVER_GETS_SUSPENDED - 1) {
                        try {
                            #add user to notify list
                            if (!in_array($user, $this->usersToNotifyBeforeSuspend)) {
                                array_push($this->usersToNotifyBeforeSuspend, $user);
                            }
                        } catch (\Exception $exception) {
                            $this->error($exception->getMessage());
                        }
                    }

                    # suspend server
                    if ($product->price == 0 && $user->last_seen->diffInDays($today) >= $this::DAYS_UNTIL_SERVER_GETS_SUSPENDED) {
                        $server->suspend();
                        $this->line("<fg=bright-magenta>Server suspended:</> <fg=blue>{$server->id}</>");
                        try {

                            #add user to notify list
                            if (!in_array($user, $this->usersToNotifySuspended)) {
                                array_push($this->usersToNotifySuspended, $user);
                            }
                        } catch (\Exception $exception) {
                            $this->error($exception->getMessage());
                        }

                    }

                }
            });

        # delete server
           Server::whereNotNull('suspended')->chunk(10, function ($servers) {
                foreach ($servers as $server) {
                $product = $server->product;
                $user = $server->user;
            if ($user->role == "admin") {
                return;
            }//Disable for admins

            $today = Carbon::today()->toDateString();

            if ($product->price == 0 && $user->last_seen->diffInDays($today) >= $this::DAYS_UNTIL_SERVER_GETS_DELETED) {
                $this->line("<fg=red>Server deleted:</> <fg=blue>{$server->id}</>");
                $server->delete();
            }
        }
        });

            return $this->notifyUsers();
        }


    /**
     * @return bool
     */
    public function notifyUsers()
    {
        if (!empty($this->usersToNotifySuspended)) {
            /** @var User $user */
            foreach ($this->usersToNotifySuspended as $user) {
                $this->line("<fg=yellow>Notified user:</> <fg=blue>{$user->name} <fg=red> Server suspended</>");
                $user->notify(new ServersSuspendedNotification());
            }
        }

        if (!empty($this->usersToNotifyBeforeSuspend)) {
            /** @var User $user */
            foreach ($this->usersToNotifyBeforeSuspend as $user) {
                $this->line("<fg=yellow>Notified user:</> <fg=blue>{$user->name} <fg=red>1 day till suspend</>");
                $user->notify(new ServersBeforeSuspendedNotification());
            }
        }

        #reset array
        $this->usersToNotifySuspended = array();
        $this->usersToNotifyBeforeSuspend = array();
        return true;
    }
}
