Hey,

thanks for buying this addon.

Installation:
Upload the Directory in the "Web_Upload" Folder to your Controlpanel Root Folder.
If asked to overwrite Files, click Yes.


To Change the days till suspension edit 
\app\Console\Commands\suspendInactive.php

Line 15 & 16
"DAYS_UNTIL_SERVER_GETS_SUSPENDED
DAYS_UNTIL_SERVER_GETS_DELETED"

Any questions or Suggestions?
Contact me on my Discord

https://discord.gg/UgJcvgCg6N