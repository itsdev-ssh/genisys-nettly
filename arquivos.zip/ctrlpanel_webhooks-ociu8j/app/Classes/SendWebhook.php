<?php

namespace App\Classes;

use Exception;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class SendWebhook
{
    const CONFIG = [
        'ticket_open' => [
            'enable' => true,
            'webhook' => 'https://discord.com/api/webhooks/1342505757182005318/Zkw5pX2DoeVHJoyPlUbxRNSSR-kWANRgBbnxrZ2b430V8bK2R8yHVqgY5TjPR1q1DM_1',
            'ping' => ['1308863494778654762']
        ],
        'ticket_reply' => [
            'enable' => true,
            'webhook' => 'your url',
            'ping' => ['1308863494778654762']
        ],
        'ticket_status_change_open' => [
            'enable' => true,
            'webhook' => 'https://discord.com/api/webhooks/1342505757182005318/Zkw5pX2DoeVHJoyPlUbxRNSSR-kWANRgBbnxrZ2b430V8bK2R8yHVqgY5TjPR1q1DM_1',
            'ping' => ['1308863494778654762']
        ],
        'ticket_status_change_close' => [
            'enable' => true,
            'webhook' => 'https://discord.com/api/webhooks/1342505757182005318/Zkw5pX2DoeVHJoyPlUbxRNSSR-kWANRgBbnxrZ2b430V8bK2R8yHVqgY5TjPR1q1DM_1',
            'ping' => ['1308863494778654762']
        ],
        'server_create' => [
            'enable' => true,
            'webhook' => 'https://discord.com/api/webhooks/1342505757182005318/Zkw5pX2DoeVHJoyPlUbxRNSSR-kWANRgBbnxrZ2b430V8bK2R8yHVqgY5TjPR1q1DM_1',
            'ping' => ['1308863494778654762']
        ],
        'server_cancel' => [
            'enable' => true,
            'webhook' => 'https://discord.com/api/webhooks/1342505757182005318/Zkw5pX2DoeVHJoyPlUbxRNSSR-kWANRgBbnxrZ2b430V8bK2R8yHVqgY5TjPR1q1DM_1',
            'ping' => ['1308863494778654762']
        ],
        'server_delete' => [
            'enable' => true,
            'webhook' => 'https://discord.com/api/webhooks/1342505757182005318/Zkw5pX2DoeVHJoyPlUbxRNSSR-kWANRgBbnxrZ2b430V8bK2R8yHVqgY5TjPR1q1DM_1',
            'ping' => ['1308863494778654762']
        ],
        'server_upgrade' => [
            'enable' => true,
            'webhook' => 'https://discord.com/api/webhooks/1342505757182005318/Zkw5pX2DoeVHJoyPlUbxRNSSR-kWANRgBbnxrZ2b430V8bK2R8yHVqgY5TjPR1q1DM_1',
            'ping' => ['1308863494778654762']
        ]
    ];

    public static function Webhook_Ticket_Open($ticket, $user)
    {
        if (!self::CONFIG['ticket_open']['enable']) {
            return;
        }
        try {
            $webhookUrl = self::CONFIG['ticket_open']['webhook'];
            $pings = array_map(function($id) {
                return "<@&$id>";
            }, self::CONFIG['ticket_open']['ping']);

            $pingList = implode(' ', $pings);
            $timestamp = time();

            Http::post($webhookUrl, [
                'content' => $pingList,
                'embeds' => [
                    [
                        'title' => 'New Ticket',
                        'fields' => [
                            [
                                'name' => 'Ticket ID',
                                'value' => $ticket->ticket_id,
                                'inline' => true
                            ],
                            [
                                'name' => 'Priority',
                                'value' => $ticket->priority,
                                'inline' => true
                            ],
                            [
                                'name' => 'Status',
                                'value' => $ticket->status,
                                'inline' => true
                            ],
                            [
                                'name' => 'Created by',
                                'value' => $user->name,
                                'inline' => true
                            ],
                            [
                                'name' => 'Timestamp',
                                'value' => "<t:$timestamp:R>",
                                'inline' => true
                            ],
                            [
                                'name' => 'Message',
                                'value' => $ticket->message,
                                'inline' => false
                            ],
                            [
                                'name' => 'View Ticket',
                                'value' => "[Click here](" . route('admin.ticket.show', $ticket->ticket_id) . ")",
                                'inline' => false
                            ]
                        ],
                        'color' => 3447003
                    ]
                ],
            ]);

        } catch (Exception $err) {
            Log::debug('Error while sending the message: ' . $err);
        }
    }
    public static function Webhook_Ticket_Reply($ticket, $user,$ticketcomment)
    {
        if (!self::CONFIG['ticket_reply']['enable']) {
            return;
        }
        try {
            $webhookUrl = self::CONFIG['ticket_reply']['webhook'];
            $pings = array_map(function($id) {
                return "<@&$id>";
            }, self::CONFIG['ticket_reply']['ping']);

            $pingList = implode(' ', $pings);
            $timestamp = time();

            Http::post($webhookUrl, [
                'content' => $pingList,
                'embeds' => [
                    [
                        'title' => 'Ticket Reply',
                        'fields' => [
                            [
                                'name' => 'Ticket ID',
                                'value' => $ticket->ticket_id,
                                'inline' => true
                            ],
                            [
                                'name' => 'Priority',
                                'value' => $ticket->priority,
                                'inline' => true
                            ],
                            [
                                'name' => 'Status',
                                'value' => $ticket->status,
                                'inline' => true
                            ],
                            [
                                'name' => 'User',
                                'value' => $user->name,
                                'inline' => true
                            ],
                            [
                                'name' => 'Timestamp',
                                'value' => "<t:$timestamp:R>",
                                'inline' => true
                            ],
                            [
                                'name' => 'Message',
                                'value' => $ticketcomment->message,
                                'inline' => false
                            ],
                            [
                                'name' => 'View Ticket',
                                'value' => "[Click here](" . route('admin.ticket.show', $ticket->ticket_id) . ")",
                                'inline' => true
                            ]
                        ],
                        'color' => 3447003
                    ]
                ],
            ]);

        } catch (Exception $err) {
            Log::debug('Error while sending the message: ' . $err);
        }
    }
    public static function Webhook_Ticket_Status_Change_Open($ticket)
    {
        if (!self::CONFIG['ticket_status_change_open']['enable']) {
            return;
        }
        try {
            $webhookUrl = self::CONFIG['ticket_status_change_open']['webhook'];
            $pings = array_map(function($id) {
                return "<@&$id>";
            }, self::CONFIG['ticket_status_change_open']['ping']);

            $pingList = implode(' ', $pings);
            $timestamp = time();

            Http::post($webhookUrl, [
                'content' => $pingList,
                'embeds' => [
                    [
                        'title' => 'Ticket Status Changed',
                        'fields' => [
                            [
                                'name' => 'Ticket ID',
                                'value' => $ticket->ticket_id,
                                'inline' => true
                            ],
                            [
                                'name' => 'Priority',
                                'value' => $ticket->priority,
                                'inline' => true
                            ],
                            [
                                'name' => 'Status',
                                'value' => $ticket->status,
                                'inline' => true
                            ],
                            [
                                'name' => 'Timestamp',
                                'value' => "<t:$timestamp:R>",
                                'inline' => true
                            ],
                            [
                                'name' => 'View Ticket',
                                'value' => "[Click here](" . route('admin.ticket.show', $ticket->ticket_id) . ")",
                                'inline' => true
                            ]
                        ],
                        'color' => 3447003
                    ]
                ],
            ]);

        } catch (Exception $err) {
            Log::debug('Error while sending the message: ' . $err);
        }
    }
    public static function Webhook_Ticket_Status_Change_Close($ticket)
    {
        if (!self::CONFIG['ticket_status_change_close']['enable']) {
            return;
        }
        try {
            $webhookUrl = self::CONFIG['ticket_status_change_close']['webhook'];
            $pings = array_map(function($id) {
                return "<@&$id>";
            }, self::CONFIG['ticket_status_change_close']['ping']);

            $pingList = implode(' ', $pings);
            $timestamp = time();

            Http::post($webhookUrl, [
                'content' => $pingList,
                'embeds' => [
                    [
                        'title' => 'Ticket Status Changed',
                        'fields' => [
                            [
                                'name' => 'Ticket ID',
                                'value' => $ticket->ticket_id,
                                'inline' => true
                            ],
                            [
                                'name' => 'Priority',
                                'value' => $ticket->priority,
                                'inline' => true
                            ],
                            [
                                'name' => 'Status',
                                'value' => $ticket->status,
                                'inline' => true
                            ],
                            [
                                'name' => 'Timestamp',
                                'value' => "<t:$timestamp:R>",
                                'inline' => true
                            ],
                            [
                                'name' => 'View Ticket',
                                'value' => "[Click here](" . route('admin.ticket.show', $ticket->ticket_id) . ")",
                                'inline' => true
                            ]
                        ],
                        'color' => 3447003
                    ]
                ],
            ]);

        } catch (Exception $err) {
            Log::debug('Error while sending the message: ' . $err);
        }
    }
    public static function Webhook_Server_Create($server,$product,$user,$node,$location,$egg)
    {
        if (!self::CONFIG['server_create']['enable']) {
            return;
        }
        try {
            $webhookUrl = self::CONFIG['server_create']['webhook'];
            $pings = array_map(function($id) {
                return "<@&$id>";
            }, self::CONFIG['server_create']['ping']);

            $pingList = implode(' ', $pings);
            $timestamp = time();

            Http::post($webhookUrl, [
                'content' => $pingList,
                'embeds' => [
                    [
                        'title' => 'Server Created',
                        'fields' => [
                            [
                                'name' => 'User',
                                'value' => $user->name,
                                'inline' => true
                            ],
                            [
                                'name' => 'Node',
                                'value' => $node->name,
                                'inline' => true
                            ],
                            [
                                'name' => 'Egg',
                                'value' => $egg->name,
                                'inline' => true
                            ],
                            [
                                'name' => 'Server Name',
                                'value' => $server->name,
                                'inline' => true
                            ],
                            [
                                'name' => 'Product',
                                'value' => "**Name**: {$product->name}\n" .
                                           "**Price**: " . rtrim(rtrim($product->price, '0'), '.') . " ({$product->billing_period})\n" .
                                           "**Memory**: {$product->memory} MB\n" .
                                           "**CPU**: {$product->cpu}%\n" .
                                           "**Swap**: {$product->swap} MB\n" .
                                           "**Disk**: {$product->disk} MB\n" .
                                           "**IO**: {$product->io}\n" .
                                           "**Databases**: {$product->databases}\n" .
                                           "**Backups**: {$product->backups}\n" .
                                           "**Allocations**: {$product->allocations}\n",
                                'inline' => true
                            ],
                            [
                                'name' => 'Timestamp',
                                'value' => "<t:$timestamp:R>",
                                'inline' => true
                            ]
                        ],
                        'color' => 3447003,
                    ]
                ],
            ]);

        } catch (Exception $err) {
            Log::debug('Error while sending the message: ' . $err);
        }
    }
    public static function Webhook_Server_Cancel($server)
    {
        if (!self::CONFIG['server_cancel']['enable']) {
            return;
        }
        try {
            $webhookUrl = self::CONFIG['server_cancel']['webhook'];
            $pings = array_map(function($id) {
                return "<@&$id>";
            }, self::CONFIG['server_cancel']['ping']);

            $pingList = implode(' ', $pings);
            $timestamp = time();

            Http::post($webhookUrl, [
                'content' => $pingList,
                'embeds' => [
                    [
                        'title' => 'Server Cancel',
                        'fields' => [
                            [
                                'name' => 'User',
                                'value' => $server->user->name,
                                'inline' => true
                            ],
                            [
                                'name' => 'Server Name',
                                'value' => $server->name,
                                'inline' => true
                            ],
                            [
                                'name' => 'Product',
                                'value' => "**Name**: {$server->product->name}\n" .
                                           "**Price**: " . rtrim(rtrim($server->product->price, '0'), '.') . " ({$server->product->billing_period})",
                                'inline' => true
                            ],
                            [
                                'name' => 'Timestamp',
                                'value' => "<t:$timestamp:R>",
                                'inline' => true
                            ]
                        ],
                        'color' => 3447003,
                    ]
                ],
            ]);

        } catch (Exception $err) {
            Log::debug('Error while sending the message: ' . $err);
        }
    }
    public static function Webhook_Server_Delete($server)
    {
        if (!self::CONFIG['server_delete']['enable']) {
            return;
        }
        try {
            $webhookUrl = self::CONFIG['server_delete']['webhook'];
            $pings = array_map(function($id) {
                return "<@&$id>";
            }, self::CONFIG['server_delete']['ping']);

            $pingList = implode(' ', $pings);
            $timestamp = time();

            Http::post($webhookUrl, [
                'content' => $pingList,
                'embeds' => [
                    [
                        'title' => 'Server Delete',
                        'fields' => [
                            [
                                'name' => 'User',
                                'value' => $server->user->name,
                                'inline' => true
                            ],
                            [
                                'name' => 'Server Name',
                                'value' => $server->name,
                                'inline' => true
                            ],
                            [
                                'name' => 'Product',
                                'value' => "**Name**: {$server->product->name}\n" .
                                           "**Price**: " . rtrim(rtrim($server->product->price, '0'), '.') . " ({$server->product->billing_period})",
                                'inline' => true
                            ],
                            [
                                'name' => 'Timestamp',
                                'value' => "<t:$timestamp:R>",
                                'inline' => true
                            ]
                        ],
                        'color' => 3447003,
                    ]
                ],
            ]);

        } catch (Exception $err) {
            Log::debug('Error while sending the message: ' . $err);
        }
    }
    public static function Webhook_Server_Upgrade($server,$newProduct,$oldProduct)
    {
        if (!self::CONFIG['server_upgrade']['enable']) {
            return;
        }
        try {
            $webhookUrl = self::CONFIG['server_upgrade']['webhook'];
            $pings = array_map(function($id) {
                return "<@&$id>";
            }, self::CONFIG['server_upgrade']['ping']);

            $pingList = implode(' ', $pings);
            $timestamp = time();

            Http::post($webhookUrl, [
                'content' => $pingList,
                'embeds' => [
                    [
                        'title' => 'Server Upgrade',
                        'fields' => [
                            [
                                'name' => 'User',
                                'value' => $server->user->name,
                                'inline' => true
                            ],
                            [
                                'name' => 'Server Name',
                                'value' => $server->name,
                                'inline' => true
                            ],
                            [
                                'name' => 'Timestamp',
                                'value' => "<t:$timestamp:R>",
                                'inline' => true
                            ],
                            [
                                'name' => 'Old Product',
                                'value' => "**Name**: {$oldProduct->name}\n" .
                                           "**Price**: " . rtrim(rtrim($oldProduct->price, '0'), '.') . " ({$oldProduct->billing_period})",
                                'inline' => true
                            ],
                            [
                                'name' => 'New Product',
                                'value' => "**Name**: {$newProduct->name}\n" .
                                           "**Price**: " . rtrim(rtrim($newProduct->price, '0'), '.') . " ({$newProduct->billing_period})",
                                'inline' => true
                            ]
                        ],
                        'color' => 3447003,
                    ]
                ],
            ]);

        } catch (Exception $err) {
            Log::debug('Error while sending the message: ' . $err);
        }
    }
}
